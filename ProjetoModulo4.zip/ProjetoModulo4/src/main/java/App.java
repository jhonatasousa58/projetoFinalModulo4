import java.nio.file.Path;
import java.time.LocalDateTime;
import java.util.Set;

public class App {
    public static void main(String[] args) {
        String movies1 = "src/main/resources/movies1.csv";
        String movies2 = "src/main/resources/movies2.csv";
        String movies3 = "src/main/resources/movies3.csv";
        Arquivos arquivos = new Arquivos(Path.of(movies1), Path.of(movies2), Path.of(movies3));

        Set<Filme> filmes = arquivos.lerArquivo();
        arquivos.escreverArquivoGeneroHorror(filmes);
        arquivos.escreverArquivoAno(filmes);

        LocalDateTime horaInicio = LocalDateTime.now();

        LocalDateTime horaFim = LocalDateTime.now();

//        filmes.forEach(System.out::println);

    }
}
